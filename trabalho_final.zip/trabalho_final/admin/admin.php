<?php session_start();
$seguranca = isset($_SESSION['ativa']) ? TRUE : header("location: login.php")
?>

<!DOCTYPE html>
<html>
<head>
	<title>Admin</title>
	<link href="style2.css" rel="stylesheet" type="text/css">
</head>
<body class="container">
	<?php if ($seguranca) { ?>
		<h1>Bem Vindo ao Painel de Admin!</h1>
		<p>Conteúdo da página administrativa.</p>
		<h2>Usuarios</h2>



		<nav>
			<div>
				<a class="login" href="admin.php">Painel</a>
				<a class="login" href="users.php">Gerenciar Usuarios</a>
				<a class="login" href="logout.php">Deslogar</a>
			</div>
		</nav>

	<?php } ?>
</body>
</html>
