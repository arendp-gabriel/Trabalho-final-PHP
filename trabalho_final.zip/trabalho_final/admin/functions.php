<?php 
$host = "localhost";
$dbUser = "root";
$dbPass = "";
$dbName = "trabalho_final";

$conecta = mysqli_connect( $host, $dbUser, $dbPass, $dbName );

function login($conecta, $senha, $usuario){
	if ($_POST['enviar']) {
		$erros = array();
		if ( empty($senha) OR empty($usuario) ) {
			$erros[] = "Usuário ou senha Inválidos";
		}

		$senha = sha1($senha);

		$query = "SELECT * FROM usuarios WHERE email = '$usuario' AND senha = '$senha' ";
		$executar = mysqli_query($conecta, $query);
		$resultado = mysqli_fetch_assoc($executar);
		//print_r($resultado);
		if ( !empty($resultado)) {
			session_start();
			$_SESSION['user'] = $resultado['nome'];
			$_SESSION['ativa'] = TRUE;
			//echo "Consegui Logar!";
			//Redireciona
			header("location: admin.php");
		}else{
			$erros[] = "Usuário ou senha não encontrados";
		}

		if (!empty($erros)) {
			foreach ($erros as $erro) {
				echo $erro . "<br>";
			}
		}		

	}
}

function logout(){
	session_start();
	//limpar caches
	session_unset();
	//Encerra a sessão
	session_destroy();
	header("location: login.php");
}

function buscaUnica($connect, $tabela, $id){
	$query = "SELECT * FROM $tabela WHERE id =". (int) "$id";
	$executar = mysqli_query($connect, $query);
	$result = mysqli_fetch_assoc($executar);
	return $result;
}

function buscar($connect, $tabela, $where = 1, $order = ""){
	if (($order)) {
		$order = "ORDER BY $order";
	}
	$query = "SELECT * FROM $tabela WHERE $where";
	$executar = mysqli_query($connect, $query);
	$results = mysqli_fetch_all($executar, MYSQLI_ASSOC);
	return $results;

}