<?php
require_once "functions.php";

//Chama a função para deslogar da sessão.
//Essa função foi criada no arquivo functions.php
logout();