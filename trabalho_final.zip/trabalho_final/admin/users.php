<?php session_start();
$seguranca = isset($_SESSION['ativa']) ? TRUE : header("location: login.php");
require_once "functions.php";
?>

<!DOCTYPE html>
<html>
<head>
	<title>Admin</title>
	<link href="style3.css" rel="stylesheet" type="text/css">
</head>
<body class="container">
	<?php if ($seguranca) { ?>
		<div class="container">
			<h1>Bem Vindo ao Painel de Admin!</h1>
			<p>Conteúdo da página administrativa.</p>
			<h2>Gerenciamento de Usuário</h2>

		<nav>
			<div>
				<a class="login" href="admin.php">Painel</a>
				<a class="login" href="users.php">Gerenciar Usuarios</a>
				<a class="login" href="logout.php">Deslogar</a>
			</div>
		</nav>
		</div>

		<?php 
		$tabela = "usuarios";
		$order = "nome";
		$usuarios = buscar($conecta, $tabela, 1, $order); 
		?>

		<div class="container">
			<table border="=1">
				<thead>
					<tr>
						<th>ID</th>
						<th>Nome</th>
						<th>Email</th>
						<th>Data Cadastro</th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ($usuarios as $usuario) : ?>
						<tr>
							<td> <?php echo $usuario['id'];?></td>
							<td> <?php echo $usuario['nome'];?></td>
							<td> <?php echo $usuario['email'];?></td>
							<td> <?php echo $usuario['data_cadastro'];?></td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>


	<?php } ?>
</body>
</html>
