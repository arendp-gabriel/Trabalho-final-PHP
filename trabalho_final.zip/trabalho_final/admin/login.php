<?php require 'functions.php'; ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Login</title>
	<link href="style.css" rel="stylesheet" type="text/css">
</head>
<body>
	<?php
	if (isset($_POST['enviar'])) {
		login($conecta, $_POST['senha'], $_POST['email']);
	}
	?>
	<form action="" method="post" class="container">
        <div>
		<input type="email" name="email" placeholder="Seu E-mail" class="login">
        </div>
        <div>
            <input type="password" name="senha" placeholder="Sua Senha" class="login">
        </div>
        <input type="submit" name="enviar" value="Acessar" class="acesso">
    </form>
</body>
</html>